<?php
$name="addstudent";
if(isset($_GET['n']))
{
	$name=$_GET['n'];
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NBBU</title>
	  
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
	<script src="js/jquery-3.3.1.min.js"></script>

	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/popper.min.js"></script> 
	<script src="js/bootstrap-4.2.1.js"></script>
    <!-- Bootstrap -->
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/css.css" rel="stylesheet" type="text/css">
	  
  </head>
  <body>
  	<!-- body code goes here -->
	<div class="main">

			<?php
		if($name=='addstudent')
		{
			include('student-entry.php');
		}
		else
		{
			include('view-student.php');
		}	
	?>
		
	</div><!-- main -->
		

