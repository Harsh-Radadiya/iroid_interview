<div class="head-line">
			<div class="head1">
			<h3>View Student</h3>
			</div>
	
	<form action="" method="POST">

	<div class="btn2">
		<input type="submit" name="srh" class="view-button" value="search" />
	</div><!-- btn2  -->
	<div class="btn2">
		<input type="text" name="search" class="view-button"  />
	</div><!-- btn2  -->		
	<div class="btn2">
		<a href="index.php?n=addstudent"><input type="button" name="add-new" class="view-button" value="Add_New" /></a>
	</div><!-- btn2  -->
	</form>
</div><!--	head-line  -->

<form action="" method="POST" class="form1">
	<table class="tbl1" border="1">
		<tr>
			<th>Image</th>
			<th>Name</th>
			<th>Email</th>
			<th>Phone</th>
			<th>Age</th>
			<th>Interest</th>
			<th>Gender</th>
			<th>Address</th>
			<th colspan="2">Opration</th>
		</tr>				
<?PHP
	if(isset($_POST['srh']))
	{
		include('dbcon.php');
		$find=$_POST['search'];
		$qry="SELECT * FROM `user` WHERE `AGE` LIKE '%$find%' ";
		$run=$con->query($qry);
		if($run->num_rows >0)
		{
			while($data=$run->fetch_assoc())
			{
			?>
			<tr>
				<td><img src="dataimg/<?php echo $data['IMG']; ?>" style="height: 100px;width: 100px;"></td>
				<td><?PHP echo $data['NAME']; ?></td>
				<td><?PHP echo $data['EMAIL'];  ?></td>
				<td><?PHP echo $data['PHONE'];  ?></td>
				<td><?PHP echo $data['AGE'];  ?></td>
				<td><?PHP echo $data['INTR'];  ?></td>
				<td><?PHP echo $data['GENDER'];  ?></td>
				<td><?PHP echo $data['ADDRESS'];  ?></td>
				<td>
					<a href="index.php?n=addstudent&uid=<?PHP echo $data['ID']; ?>&update"><img src="picture/update.png" name="update" alt="update"></a>
				</td>
				<td>	
					<a href="index.php?n=addstudent&uid=<?PHP echo $data['ID']; ?>&delete"><img src="picture/delete.png" name="delete" alt="delete"></a>
				</td>
			</tr>
		<?PHP
			}
		}
	}
	else
	{
		include('dbcon.php');
		$qry="SELECT * FROM `user` WHERE 1";
		$run=$con->query($qry);
		if($run->num_rows >0)
		{
			while($data=$run->fetch_assoc())
			{
				?>
		<tr>
				<td><img src="dataimg/<?php echo $data['img']; ?>" style="height: 100px;width: 100px;"></td>
				<td><?PHP echo $data['NAME'];  ?></td>
				<td><?PHP echo $data['EMAIL'];  ?></td>
				<td><?PHP echo $data['PHONE'];  ?></td>
				<td><?PHP echo $data['AGE'];  ?></td>
				<td><?PHP echo $data['INTR'];  ?></td>
				<td><?PHP echo $data['GENDER'];  ?></td>
				<td><?PHP echo $data['ADDRESS'];  ?></td>
				<td>
					<a href="index.php?n=addstudent&uid=<?PHP echo $data['ID']; ?>&update"><img src="picture/update.png" name="update" title="update" alt="update"></a>
				</td>
				<td>
					<a href="index.php?n=addstudent&uid=<?PHP echo $data['ID']; ?>&delete"><img src="picture/delete.png" name="delete" title="delete" alt="delete"></a>
				</td>
		</tr>	
				<?PHP	
			}
		}
	}
		?>
	</table>
</form>	