<div id="login_form">
    <form name="f1" method="post" action="login.php" id="f1">
        <table>
            <tr>
                <td class="f1_label">User Name :</td>
                <td><input type="text" name="username" value="" />
                </td>
            </tr>
            <tr>
                <td class="f1_label">Password :</td>
                <td><input type="password" name="password" value="" />
                </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" name="login" value="Log In" style="font-size:18px; " />
                </td>
                <td>
                    <input type="submit" name="register" value="Register" style="font-size:18px; " />
                </td>
            </tr>

        </table>
    </form>
</div>