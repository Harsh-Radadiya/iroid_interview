 <?php

$con=new mysqli('localhost','root','','iroid');

if($con->connect_error)
{
	echo "Connection not done";
	
}

?>