<?PHP


if(isset($_POST['update']))
{
	include('dbcon.php');
	$id=$_GET['uid'];
	$name=$_POST['uname'];
	$gender=$_POST['gender'];
	$dob=$_POST['dob'];
	$today = date("Y-m-d");
	$diff = date_diff(date_create($dob), date_create($today));
	$age=$diff->format('%y');
	$int=$_POST['int'];
	$pcont=$_POST['contect'];
	$email=$_POST['email'];
	$add=$_POST['address'];
	$img = $_FILES['img']['name'];
	$tempname=$_FILES['img']['tmp_name'];
	
	move_uploaded_file($tempname,"picture/$img");
		
	$qry="UPDATE `user` SET `IMG`='$img' `FIRSTNAME`='$name',`GENDER`='$gender', `DATEOFBIRTH`='$dob',`AGE`='$age',`INTR`='$int',`PHONE`='$pcont',`EMAIL`='$email',`ADDRESS`='$add' WHERE `NO`=$id";
	$run=$con->query($qry);
	
	if($run == TRUE)
	{
		?>
		
			<script>alert('Data Updated!!');
				
			window.open('index.php?n=viewstudent','_self');
		
		</script>
<?PHP
	}
}
if(isset($_POST['submit']))
{
	include('dbcon.php');
	$name=$_POST['uname'];
	$gender=$_POST['gender'];
	$dob=$_POST['dob'];
	$today = date("Y-m-d");
	$diff = date_diff(date_create($dob), date_create($today));
	$age=$diff->format('%y');
	$int=$_POST['int'];
	$pcont=$_POST['contect'];
	$email=$_POST['email'];
	$add=$_POST['address'];
	$img = $_FILES['img']['name'];
	$tempname=$_FILES['img']['tmp_name'];
	
	move_uploaded_file($tempname,"picture/$img");
		
	$qry="INSERT INTO `user` (`IMG`, `NAME`, `EMAIL`, `PHONE`, `DATEOFBIRTH`, `AGE`, `INTR`, `GENDER`, `ADDRESS`) VALUES ('$img','$name','$email','$pcont','$dob', '$age','$int','$gender','$add')";
	$run=$con->query($qry);
	
	if($run == TRUE)
	{
		?>
		<script>
				alert('Data Inserted!!');
			window.open('index.php?n=viewstudent','_self');
		</script>
		<?php
	}
}
if(isset($_GET['uid']))
{
	if(isset($_GET['update']))
	{	
		include('dbcon.php');
		$id=$_GET['uid'];
		$qry="SELECT * FROM `user` WHERE `ID`=$id";
		$run=$con->query($qry);
		if($run->num_rows > 0)
		{
			$data=$run->fetch_assoc();	
		}
	}
	if(isset($_GET['delete']))
	{
		include('dbcon.php');
		$id=$_GET['uid'];
		$qry="DELETE FROM `user` WHERE `ID`=$id";
		$run=$con->query($qry);
		if($run == TRUE)
		{
			?>
			<script>
				alert('Data Deleted!!');
				window.open('index.php?n=viewstudent','_self');
			</script>
			<?php
		}
	}
}

?>
<div class="head-line">
			<div class="head">
			<h3>Student Entry</h3>
			</div>
			<div class="btn1">
				<a href="index.php?n=viewstudent"><input type="button" name="vstudent" class="view-button" value="View_Student" /></a>
			</div><!-- btn1  -->
			</div><!--	head-line  -->
			<form action="" method="POST" class="form" autocomplete="off">
				<table class="tbl">
					<tr>	
						<th class="tblsp1">Image:</th>
						<td>
							<input type="file" name="img" class="text-dark len" value="<?php if(isset($_GET['uid'])){ echo $data['img'];}  ?>" >
						</td>
					</tr>
					<tr>
						<th class="tblsp1">Name:</th>
						<td><input type="text" name="uname" class="text-dark len" value="<?php if(isset($_GET['uid'])){ echo $data['NAME'];}  ?>" required></td>
					</tr>
					<tr>	
						<th class="tblsp1">Email:</th>
						<td><input type="email" name="email" class="text-dark len" value="<?php if(isset($_GET['uid'])){ echo $data['EMAIL'];}  ?>" required></td>
					</tr>
					<tr>
						<th class="tblsp1">Phone:</th>
						<td><input type="tel" name="contect" maxlength="10" class="text-dark len" value="<?php if(isset($_GET['uid'])) { echo $data['PHONE']; } ?>" required></td>
					</tr>
					<tr>
						<th class="tblsp1">Date of Birth:</th>
						<td><input type="date" name="dob" class="text-dark len" value="<?php if(isset($_GET['uid'])) { echo $data['DATEOFBIRTH']; } ?>" required></td>
					
					</tr>
					<tr>
						<th class="tblsp1">Interest:</th>
						<td><input type="text" name="int" class="text-dark len" value="<?php if(isset($_GET['uid'])) { echo $data['INTR']; }  ?>" required></td>
					</tr>
					<tr>
						<th class="tblsp1">Gender:</th>
						<td>
							<input type="radio" name="gender" class="radio" value="Male" <?php if(isset($_GET['uid'])) { if($data['GENDER']=="Male") { echo('checked');  } } ?> >  <strong>Male</strong>
							<input type="radio" name="gender" class="radio" value="Female" <?php if(isset($_GET['uid'])) { if($data['GENDER']=="Female") { echo('checked');  } } ?> >  <strong>Female</strong>
						</td>
					</tr>
					<tr>
						<th class="tblsp1" >Address:</th>
						<td >
							<textarea rows="5" cols="25" name="address"  required><?php if(isset($_GET['uid'])) { echo $data['ADDRESS']; } ?></textarea>
						</td>
					</tr>  
					<tr>
						<td class="tblsp1"></td>
						<td class="pt-3">
						<input type="submit" name="<?php if(isset($_GET['uid'])){ echo 'update'; } else {echo 'submit';}?>" class="view-button1" value="<?php if(isset($_GET['uid'])){ echo 'update'; } else {echo 'submit';}?>" />
						<input type="reset" name="reset" class="view-button1" value="Reset" />
						</td>	
					</tr>
				
				</table>
			</form>

  </body>
</html>